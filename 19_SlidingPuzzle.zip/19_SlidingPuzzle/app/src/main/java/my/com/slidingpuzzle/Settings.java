package my.com.slidingpuzzle;

public class Settings {
    static public int size = 3;

    static public boolean isMusic = true;
    static public boolean isSound = true;
    static public boolean isVib = true;

} // Settings
