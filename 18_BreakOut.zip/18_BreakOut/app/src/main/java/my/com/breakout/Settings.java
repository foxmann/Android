package my.com.breakout;

public class Settings {
    static public boolean isMusic = true;
    static public boolean isSound = true;
    static public boolean isVib = true;
} // Settings
